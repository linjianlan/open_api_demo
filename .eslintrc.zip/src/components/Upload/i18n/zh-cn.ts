export default {
	excel: {
		downloadTemplate: '下载模板',
		fileFormat: '仅允许导入xls、xlsx格式文件。',
		operationNotice: '将文件拖到此处，或',
		clickUpload: '点击上传',
		lineNumbers: '行号',
		misDescription: '错误描述',
		validationFailureData: '校验失败数据',
		pleaseUpload: '请上传',
		size: '大小不超过',
		format: '格式为',
		file: '的文件',
		sizeErrorText: '文件大小不超过',
		typeErrorText: '文件类型错误，请上传 ',
	},
};
