export default {
   demo: {
        index: '#',
        importdemoTip: '导入demo 表',
        id: '主键',
        username: '用户名',
        nicename: '昵称',
        createBy: '创建人',
        createTime: '创建时间',
        updateBy: '更新人',
        updateTime: '修改时间',
        inputIdTip: '请输入主键',
        inputUsernameTip: '请输入用户名',
        inputNicenameTip: '请输入昵称',
        inputCreateByTip: '请输入创建人',
        inputCreateTimeTip: '请输入创建时间',
        inputUpdateByTip: '请输入更新人',
        inputUpdateTimeTip: '请输入修改时间',
    }
}