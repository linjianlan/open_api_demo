export default {
   flowRvaporationReport: {
        index: '#',
        importflowRvaporationReportTip: 'import FlowRvaporationReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}