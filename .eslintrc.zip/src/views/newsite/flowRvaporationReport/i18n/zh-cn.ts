export default {
   flowRvaporationReport: {
        index: '#',
        importflowRvaporationReportTip: '导入流量蒸发量报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}