export default {
   rainReport: {
        index: '#',
        importrainReportTip: 'import RainReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}