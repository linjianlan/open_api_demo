export default {
   rainReport: {
        index: '#',
        importrainReportTip: '导入雨情报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}