export default {
   seepageReport: {
        index: '#',
        importseepageReportTip: 'import SeepageReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}