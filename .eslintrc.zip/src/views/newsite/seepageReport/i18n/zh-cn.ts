export default {
   seepageReport: {
        index: '#',
        importseepageReportTip: '导入渗流报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}