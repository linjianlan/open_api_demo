export default {
   typhoonPath: {
        index: '#',
        importtyphoonPathTip: '导入台风路径',
        id: ' id',
        date: ' date',
        inputIdTip: '请输入 id',
        inputDateTip: '请输入 date',
    }
}