export default {
   typhoonPath: {
        index: '#',
        importtyphoonPathTip: 'import TyphoonPath',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}