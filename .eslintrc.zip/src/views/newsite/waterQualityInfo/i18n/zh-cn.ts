export default {
   waterQualityInfo: {
        index: '#',
        importwaterQualityInfoTip: '导入水质信息',
        id: ' id',
        date: ' date',
        inputIdTip: '请输入 id',
        inputDateTip: '请输入 date',
    }
}