export default {
   waterQualityInfo: {
        index: '#',
        importwaterQualityInfoTip: 'import WaterQualityInfo',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}