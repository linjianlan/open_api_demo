export default {
   statisticalReport: {
        index: '#',
        importstatisticalReportTip: 'import StatisticalReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}