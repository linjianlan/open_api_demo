export default {
   statisticalReport: {
        index: '#',
        importstatisticalReportTip: '导入统计报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}