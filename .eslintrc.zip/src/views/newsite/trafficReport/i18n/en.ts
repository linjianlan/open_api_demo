export default {
   trafficReport: {
        index: '#',
        importtrafficReportTip: 'import TrafficReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}