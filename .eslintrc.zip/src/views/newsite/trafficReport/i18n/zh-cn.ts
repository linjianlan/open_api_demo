export default {
   trafficReport: {
        index: '#',
        importtrafficReportTip: '导入流量报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}