export default {
   waterInfo: {
        index: '#',
        importwaterInfoTip: 'import WaterInfo',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}