export default {
   waterInfo: {
        index: '#',
        importwaterInfoTip: '导入水情信息',
        id: ' id',
        date: ' date',
        inputIdTip: '请输入 id',
        inputDateTip: '请输入 date',
    }
}