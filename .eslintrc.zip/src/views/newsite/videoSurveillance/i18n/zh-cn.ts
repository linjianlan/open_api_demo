export default {
   videoSurveillance: {
        index: '#',
        importvideoSurveillanceTip: '导入视频监控',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}