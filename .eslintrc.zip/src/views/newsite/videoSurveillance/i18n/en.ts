export default {
   videoSurveillance: {
        index: '#',
        importvideoSurveillanceTip: 'import VideoSurveillance',
        id: 'id',
        inputIdTip: 'input id',
    }
}