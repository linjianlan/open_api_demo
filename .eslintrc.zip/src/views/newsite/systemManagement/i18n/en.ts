export default {
   systemManagement: {
        index: '#',
        importsystemManagementTip: 'import SystemManagement',
        id: 'id',
        inputIdTip: 'input id',
    }
}