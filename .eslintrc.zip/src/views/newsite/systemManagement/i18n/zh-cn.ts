export default {
   systemManagement: {
        index: '#',
        importsystemManagementTip: '导入系统管理',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}