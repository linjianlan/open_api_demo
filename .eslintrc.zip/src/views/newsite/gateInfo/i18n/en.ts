export default {
   gateInfo: {
        index: '#',
        importgateInfoTip: 'import GateInfo',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}