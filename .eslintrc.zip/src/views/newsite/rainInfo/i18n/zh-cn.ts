export default {
   rainInfo: {
        index: '#',
        importrainInfoTip: '导入雨情信息',
        id: ' id',
        catere: ' catere',
        inputIdTip: '请输入 id',
        inputCatereTip: '请输入 catere',
    }
}