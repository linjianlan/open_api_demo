export default {
   rainInfo: {
        index: '#',
        importrainInfoTip: 'import RainInfo',
        id: 'id',
        catere: 'catere',
        inputIdTip: 'input id',
        inputCatereTip: 'input catere',
    }
}