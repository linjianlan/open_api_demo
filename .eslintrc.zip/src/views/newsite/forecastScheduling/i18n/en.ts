export default {
   forecastScheduling: {
        index: '#',
        importforecastSchedulingTip: 'import ForecastScheduling',
        id: 'id',
        inputIdTip: 'input id',
    }
}