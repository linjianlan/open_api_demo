export default {
   forecastScheduling: {
        index: '#',
        importforecastSchedulingTip: '导入预报调度',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}