export default {
   analysisWaterRainConditions: {
        index: '#',
        importanalysisWaterRainConditionsTip: 'import AnalysisWaterRainConditions',
        id: 'id',
        inputIdTip: 'input id',
    }
}