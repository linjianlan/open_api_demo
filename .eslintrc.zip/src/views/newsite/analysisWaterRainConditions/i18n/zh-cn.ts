export default {
   analysisWaterRainConditions: {
        index: '#',
        importanalysisWaterRainConditionsTip: '导入水雨情分析',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}