export default {
   trafficMonitoring: {
        index: '#',
        importtrafficMonitoringTip: 'import TrafficMonitoring',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}