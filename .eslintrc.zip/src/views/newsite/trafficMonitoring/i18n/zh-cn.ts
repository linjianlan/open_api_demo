export default {
   trafficMonitoring: {
        index: '#',
        importtrafficMonitoringTip: '导入流量监控',
        id: ' id',
        date: ' date',
        inputIdTip: '请输入 id',
        inputDateTip: '请输入 date',
    }
}