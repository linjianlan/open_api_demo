export default {
   information: {
        index: '#',
        importinformationTip: 'import Information',
        infoId: 'infoId',
        infoCreateTime: 'infoCreateTime',
        infotagId: 'infotagId',
        infoTitle: 'infoTitle',
        infoTag: 'infoTag',
        infoImg: 'infoImg',
        infoContentHtml: 'infoContentHtml',
        infoLook: 'infoLook',
        inputInfoIdTip: 'input infoId',
        inputInfoCreateTimeTip: 'input infoCreateTime',
        inputInfotagIdTip: 'input infotagId',
        inputInfoTitleTip: 'input infoTitle',
        inputInfoTagTip: 'input infoTag',
        inputInfoImgTip: 'input infoImg',
        inputInfoContentHtmlTip: 'input infoContentHtml',
        inputInfoLookTip: 'input infoLook',
    }
}