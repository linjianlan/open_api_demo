export default {
   waterSituationReport: {
        index: '#',
        importwaterSituationReportTip: '导入 水情报表',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}