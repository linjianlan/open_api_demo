export default {
   waterSituationReport: {
        index: '#',
        importwaterSituationReportTip: 'import WaterSituationReport',
        id: 'id',
        inputIdTip: 'input id',
    }
}