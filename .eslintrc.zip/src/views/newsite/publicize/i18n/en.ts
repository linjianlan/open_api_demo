export default {
   publicize: {
        index: '#',
        importpublicizeTip: 'import Publicize',
        pubId: 'pubId',
        pubCreateTime: 'pubCreateTime',
        pubData: 'pubData',
        pubIcon: 'pubIcon',
        pubContent: 'pubContent',
        pubDetailed: 'pubDetailed',
        pubIndex: 'pubIndex',
        inputPubIdTip: 'input pubId',
        inputPubCreateTimeTip: 'input pubCreateTime',
        inputPubDataTip: 'input pubData',
        inputPubIconTip: 'input pubIcon',
        inputPubContentTip: 'input pubContent',
        inputPubDetailedTip: 'input pubDetailed',
        inputPubIndexTip: 'input pubIndex',
    }
}