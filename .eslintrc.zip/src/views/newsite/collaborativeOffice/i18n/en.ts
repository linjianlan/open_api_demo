export default {
   collaborativeOffice: {
        index: '#',
        importcollaborativeOfficeTip: 'import CollaborativeOffice',
        id: 'id',
        inputIdTip: 'input id',
    }
}