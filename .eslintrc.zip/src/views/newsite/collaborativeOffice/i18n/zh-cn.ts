export default {
   collaborativeOffice: {
        index: '#',
        importcollaborativeOfficeTip: '导入协同办公',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}