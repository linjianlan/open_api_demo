export default {
   engineeringInspection: {
        index: '#',
        importengineeringInspectionTip: 'import EngineeringInspection',
        id: 'id',
        inputIdTip: 'input id',
    }
}