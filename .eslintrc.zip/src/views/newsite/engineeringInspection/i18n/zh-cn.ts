export default {
   engineeringInspection: {
        index: '#',
        importengineeringInspectionTip: '导入 工程巡查',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}