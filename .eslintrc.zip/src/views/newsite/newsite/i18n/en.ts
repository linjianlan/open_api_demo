export default {
   newsite: {
        index: '#',
        importnewsiteTip: 'import newsite',
        id: 'id',
        username: 'username',
        nicename: 'nicename',
        createBy: 'createBy',
        createTime: 'createTime',
        updateBy: 'updateBy',
        updateTime: 'updateTime',
        inputIdTip: 'input id',
        inputUsernameTip: 'input username',
        inputNicenameTip: 'input nicename',
        inputCreateByTip: 'input createBy',
        inputCreateTimeTip: 'input createTime',
        inputUpdateByTip: 'input updateBy',
        inputUpdateTimeTip: 'input updateTime',
    }
}