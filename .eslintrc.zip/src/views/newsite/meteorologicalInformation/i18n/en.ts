export default {
   meteorologicalInformation: {
        index: '#',
        importmeteorologicalInformationTip: 'import MeteorologicalInformation',
        id: 'id',
        date: 'date',
        inputIdTip: 'input id',
        inputDateTip: 'input date',
    }
}