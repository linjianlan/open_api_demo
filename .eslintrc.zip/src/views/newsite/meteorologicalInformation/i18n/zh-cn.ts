export default {
   meteorologicalInformation: {
        index: '#',
        importmeteorologicalInformationTip: '导入气象信息',
        id: ' id',
        date: ' date',
        inputIdTip: '请输入 id',
        inputDateTip: '请输入 date',
    }
}