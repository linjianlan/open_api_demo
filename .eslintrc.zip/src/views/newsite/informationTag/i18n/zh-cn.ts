export default {
   informationTag: {
        index: '#',
        importinformationTagTip: '导入资讯标题表',
        infotagId: '创建id',
        infotagTitle: '标题',
        inputInfotagIdTip: '请输入创建id',
        inputInfotagTitleTip: '请输入标题',
    }
}