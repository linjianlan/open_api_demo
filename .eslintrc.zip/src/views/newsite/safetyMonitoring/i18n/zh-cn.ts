export default {
   safetyMonitoring: {
        index: '#',
        importsafetyMonitoringTip: '导入安全监控',
        id: ' id',
        inputIdTip: '请输入 id',
    }
}