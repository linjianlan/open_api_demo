export default {
   safetyMonitoring: {
        index: '#',
        importsafetyMonitoringTip: 'import SafetyMonitoring',
        id: 'id',
        inputIdTip: 'input id',
    }
}