export default {
	template: {
		index: '#',
		importgenTemplateTip: '导入模板',
		id: '主键',
		templateName: '模板名称',
		generatorPath: '模板路径',
		desc: '模板描述',
		createTime: '创建时间',
		inputIdTip: '请输入主键',
		inputTemplateNameTip: '请输入模板名称',
		inputGeneratorPathTip: '请输入模板路径',
		inputDescTip: '请输入模板描述',
		templateCode: '模板代码',
		inputTemplateCode: '请输入模板代码',
	},
};
