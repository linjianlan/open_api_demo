export default {
	fieldtype: {
		index: '#',
		importFieldTypeTip: ' import FieldType',
		id: 'id',
		columnType: 'columnType',
		attrType: 'attrType',
		packageName: 'packageName',
		createTime: 'createTime',
		inputidTip: 'input id',
		inputcolumnTypeTip: 'input columnType',
		inputattrTypeTip: 'input attrType',
		inputpackageNameTip: 'input packageName',
		inputcreateTimeTip: 'input createTime',
	},
};
