export default {
	systoken: {
		index: '#',
		userId: '用户ID',
		username: '用户名',
		clientId: '客户端',
		accessToken: '令牌',
		expiresAt: '过期时间',
		inputUsernameTip: '请输入用户名',
		offlineBtn: '下线',
		offlineConfirmText: '确认下线',
		offlineSuccessText: '下线成功',
	},
};
