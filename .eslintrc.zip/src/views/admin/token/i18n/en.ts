export default {
	systoken: {
		index: '#',
		userId: 'userId',
		username: 'username',
		clientId: 'clientId',
		accessToken: 'accessToken',
		expiresAt: 'expiresAt',
		inputUsernameTip: 'input Username',
		offlineBtn: 'offline',
		offlineConfirmText: 'offline confirm',
		offlineSuccessText: 'offline success',
	},
};
