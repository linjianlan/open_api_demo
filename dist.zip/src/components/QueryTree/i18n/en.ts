export default {
    queryTree: {
        hideSearch: 'hideSearch',
        displayTheSearch: 'displayTheSearch',
        refresh: 'refresh',
        print: 'print',
        view: 'view'
    },
};
