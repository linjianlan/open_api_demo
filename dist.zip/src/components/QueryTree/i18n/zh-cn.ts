export default {
	queryTree: {
		hideSearch: '隐藏搜索',
		displayTheSearch: '显示搜索',
		refresh: '刷新',
		print: '打印',
		view: '视图'
	},
};
