export default {
	excel: {
		downloadTemplate: 'downloading the template',
		fileFormat: 'only xls, xlsx format files are allowed',
		operationNotice: 'Drag the file here and',
		clickUpload: 'click upload',
		lineNumbers: 'line numbers',
		misDescription: 'misDescription',
		validationFailureData: 'validation failure data',
		pleaseUpload: 'please upload',
		size: 'size not exceeding',
		format: 'format',
		file: 'file',
		sizeErrorText: 'file size error, max ',
		typeErrorText: 'file type error, upload ',
	},
};
