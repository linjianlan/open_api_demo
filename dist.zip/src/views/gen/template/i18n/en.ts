export default {
	template: {
		index: '#',
		importgenTemplateTip: 'import GenTemplate',
		id: 'id',
		templateName: 'templateName',
		generatorPath: 'generatorPath',
		desc: 'templateDesc',
		createTime: 'createTime',
		inputIdTip: 'input id',
		inputTemplateNameTip: 'input templateName',
		inputGeneratorPathTip: 'input generatorPath',
		inputDescTip: 'input templateDesc',
		templateCode: 'template code',
		inputTemplateCode: 'input template Code',
	},
};
