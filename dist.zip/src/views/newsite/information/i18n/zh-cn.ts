export default {
   information: {
        index: '#',
        importinformationTip: '导入资讯表',
        infoId: '创建id',
        infoCreateTime: '创建时间',
        infotagId: '标签表id',
        infoTitle: '标题',
        infoTag: '标签',
        infoImg: '展示图',
        infoContentHtml: '内容',
        infoLook: '阅读量',
        inputInfoIdTip: '请输入创建id',
        inputInfoCreateTimeTip: '请输入创建时间',
        inputInfotagIdTip: '请输入标签表id',
        inputInfoTitleTip: '请输入标题',
        inputInfoTagTip: '请输入标签',
        inputInfoImgTip: '请输入展示图',
        inputInfoContentHtmlTip: '请输入内容',
        inputInfoLookTip: '请输入阅读量',
    }
}