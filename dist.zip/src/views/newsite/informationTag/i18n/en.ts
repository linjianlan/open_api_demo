export default {
   informationTag: {
        index: '#',
        importinformationTagTip: 'import InformationTag',
        infotagId: 'infotagId',
        infotagTitle: 'infotagTitle',
        inputInfotagIdTip: 'input infotagId',
        inputInfotagTitleTip: 'input infotagTitle',
    }
}