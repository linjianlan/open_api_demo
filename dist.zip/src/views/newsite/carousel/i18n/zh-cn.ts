export default {
   carousel: {
        index: '#',
        importcarouselTip: '导入轮播表',
        caroId: ' caroId',
        caroCreatTime: ' caroCreatTime',
        caroTitle: '标题',
        caroUrl: '图片路径',
        caroContent: '宣传语',
        caroButton: '跳转按钮介绍',
        caroSkip: '跳转路径',
        inputCaroIdTip: '请输入 caroId',
        inputCaroCreatTimeTip: '请输入 caroCreatTime',
        inputCaroTitleTip: '请输入标题',
        inputCaroUrlTip: '请输入图片路径',
        inputCaroContentTip: '请输入宣传语',
        inputCaroButtonTip: '请输入跳转按钮介绍',
        inputCaroSkipTip: '请输入跳转路径',
    }
}