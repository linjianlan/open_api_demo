export default {
   projectCases: {
        index: '#',
        importprojectCasesTip: '导入项目案例',
        pcId: ' pcId',
        pcTitbParentId: '标题id',
        pcTitle: '案例标题',
        pcImg: '展示图片',
        pcCreateTime: '创建时间',
        pcContent: '内容简介',
        pcDeilHtml: '详细html',
        pcTag: '标签',
        pcLook: '阅读次数',
        inputPcIdTip: '请输入 pcId',
        inputPcTitbParentIdTip: '请输入标题id',
        inputPcTitleTip: '请输入案例标题',
        inputPcImgTip: '请输入展示图片',
        inputPcCreateTimeTip: '请输入创建时间',
        inputPcContentTip: '请输入内容简介',
        inputPcDeilHtmlTip: '请输入详细html',
        inputPcTagTip: '请输入标签',
        inputPcLookTip: '请输入阅读次数',
    }
}