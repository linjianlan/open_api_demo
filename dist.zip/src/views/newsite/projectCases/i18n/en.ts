export default {
   projectCases: {
        index: '#',
        importprojectCasesTip: 'import ProjectCases',
        pcId: 'pcId',
        pcTitbParentId: 'pcTitbParentId',
        pcTitle: 'pcTitle',
        pcImg: 'pcImg',
        pcCreateTime: 'pcCreateTime',
        pcContent: 'pcContent',
        pcDeilHtml: 'pcDeilHtml',
        pcTag: 'pcTag',
        pcLook: 'pcLook',
        inputPcIdTip: 'input pcId',
        inputPcTitbParentIdTip: 'input pcTitbParentId',
        inputPcTitleTip: 'input pcTitle',
        inputPcImgTip: 'input pcImg',
        inputPcCreateTimeTip: 'input pcCreateTime',
        inputPcContentTip: 'input pcContent',
        inputPcDeilHtmlTip: 'input pcDeilHtml',
        inputPcTagTip: 'input pcTag',
        inputPcLookTip: 'input pcLook',
    }
}