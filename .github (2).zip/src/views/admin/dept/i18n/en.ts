export default {
	sysdept: {
		name: 'dept name',
		parentId: 'parent dept',
		createTime: 'createTime',
		weight: 'weight',
		sortOrder: 'sortOrder',
		inputdeptNameTip: 'input deptName',
		inputnameTip: 'input deptName',
		inputparentIdTip: 'select deptName',
		inputsortOrderTip: 'input sortOrder',
		importTip: 'import dept',
	},
};
