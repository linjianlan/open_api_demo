export default {
	pig_website: {
		index: '#',
		importpigWebsiteTip: 'import PigWebsite',
		id: 'id',
		username: 'username',
		password: 'password',
		delFlag: 'delFlag',
		inputIdTip: 'input id',
		inputUsernameTip: 'input username',
		inputPasswordTip: 'input password',
		inputDelFlagTip: 'input delFlag',
	},
};
