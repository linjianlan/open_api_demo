export default {
   carousel: {
        index: '#',
        importcarouselTip: 'import Carousel',
        caroId: 'caroId',
        caroCreatTime: 'caroCreatTime',
        caroTitle: 'caroTitle',
        caroUrl: 'caroUrl',
        caroContent: 'caroContent',
        caroButton: 'caroButton',
        caroSkip: 'caroSkip',
        inputCaroIdTip: 'input caroId',
        inputCaroCreatTimeTip: 'input caroCreatTime',
        inputCaroTitleTip: 'input caroTitle',
        inputCaroUrlTip: 'input caroUrl',
        inputCaroContentTip: 'input caroContent',
        inputCaroButtonTip: 'input caroButton',
        inputCaroSkipTip: 'input caroSkip',
    }
}