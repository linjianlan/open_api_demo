export default {
   publicize: {
        index: '#',
        importpublicizeTip: '导入宣传表 字典表',
        pubId: ' pubId',
        pubCreateTime: '创建时间',
        pubData: '数据',
        pubIcon: '图标',
        pubContent: '描述',
        pubDetailed: '详细',
        pubIndex: '排序',
        inputPubIdTip: '请输入 pubId',
        inputPubCreateTimeTip: '请输入创建时间',
        inputPubDataTip: '请输入数据',
        inputPubIconTip: '请输入图标',
        inputPubContentTip: '请输入描述',
        inputPubDetailedTip: '请输入详细',
        inputPubIndexTip: '请输入排序',
    }
}