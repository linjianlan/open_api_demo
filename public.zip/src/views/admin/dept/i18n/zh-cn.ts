export default {
	sysdept: {
		name: '部门名称',
		parentId: '上级部门',
		createTime: '创建时间',
		weight: '排序',
		sortOrder: '排序',
		inputdeptNameTip: '请输入部门名称',
		inputnameTip: '请输入部门名称',
		inputparentIdTip: '请选择上级部门',
		inputsortOrderTip: '请输入排序',
		importTip: '导入部门',
	},
};
