export default {
	sysrole: {
		index: '#',
		roleName: '角色名称',
		inputRoleNameTip: '请输入角色名称',
		permissionTip: '授权',
		deleteDisabledTip: '角色不允许删除',

		roleCode: '角色标识',
		roleDesc: '角色描述',
		data_authority: '数据权限',
		createTime: '创建时间',
		please_enter_a_role_name: '请输入角色名称',
		please_enter_the_role_Code: '请输入角色标识',
		please_enter_the_role_description: '请输入角色描述',
		menu_authority: '数据权限',
		please_select: 'please select',
	},
};
