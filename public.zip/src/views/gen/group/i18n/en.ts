export default {
	group: {
		index: '#',
		importgenGroupTip: 'import GenGroup',
		id: 'id',
		groupName: 'groupName',
		groupDesc: 'groupDesc',
		inputIdTip: 'input id',
		createTime: 'createTime',
		inputGroupNameTip: 'input groupName',
		inputGroupDescTip: 'input groupDesc',
		templateType: 'template Type',
		selectType: 'please select a template type',
	},
};
