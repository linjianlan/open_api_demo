export default {
	group: {
		index: '#',
		importgenGroupTip: '导入模板分组',
		id: ' id',
		groupName: '分组名称',
		groupDesc: '分组描述',
		createTime: '创建时间',
		inputIdTip: '请输入 id',
		inputGroupNameTip: '请输入分组名称',
		inputGroupDescTip: '请输入分组描述',
		templateType: '模板类型',
		selectType: '请选择模板类型',
	},
};
