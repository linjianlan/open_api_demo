export default {
	fieldtype: {
		index: '#',
		importFieldTypeTip: '导入列属性',
		id: 'id',
		columnType: '字段类型',
		attrType: '属性类型',
		packageName: '属性包名',
		createTime: '创建时间',
		inputidTip: '请输入id',
		inputcolumnTypeTip: '请输入字段类型',
		inputattrTypeTip: '请输入属性类型',
		inputpackageNameTip: '请输入属性包名',
		inputcreateTimeTip: '请输入创建时间',
	},
};
