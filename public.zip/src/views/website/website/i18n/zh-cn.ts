export default {
   website: {
        index: '#',
        importpigWebsiteTip: '导入demo 表',
        id: '编号',
        username: '用户名',
        password: '密码',
        delFlag: '删除标记',
        inputIdTip: '请输入编号',
        inputUsernameTip: '请输入用户名',
        inputPasswordTip: '请输入密码',
        inputDelFlagTip: '请输入删除标记',
    }
}